 <!DOCTYPE html>
 <html>

 <head>
     <?php include('include/head.php');?>
     <style>
     /* .bg-opacity 
         background: url"images/big/bg.jpeg" no-repeat center center;
         background-size: cover;
         height: 100vh;
     
     .bg-opacity::before  */

     .bg-opacity {


         background-image: linear-gradient(to right, #10ac84, #f9ca24);
         height: 100vh;
     }
     </style>

 </head>

 <body>
     <section class="parent-section bg-opacity d-flex align-items-center justify-content-center">

         <div class="container">
             <div class="row">
                 <div class="col-12 text-center">
                     <div class="">
                         <!-- <img class="mr-3" src="images/avatar/11.png" width="80" height="80" alt=""> -->

                         <h1 class="text-white blue-italic">Chalo!!!<span><i class=""></i></span></h1>
                     </div>

                 </div>
             </div>
         </div>




     </section><!-- PARENT SECTION -->


     <?php include('include/footer.php');?>



 </body>