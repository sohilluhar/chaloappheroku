jQuery(function($){
	$('#table').footable();
});