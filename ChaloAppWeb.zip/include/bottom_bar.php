<br><br> <br><br><br><br>
<section class="section2 fixed-section1 bg-primary">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-center custom_icon1">
                    <span class="mdi mdi-menu-up mdi-24px text-white">Invites</span>
                </div>
            </div>
        </div>
        <div class="text-white">
            <hr>
        </div>
        <nav class="mobile-bottom-nav">

            <div class="mobile-bottom-nav__item">
                <a href="all_activity.php" class="text-white">
                    <div class="mobile-bottom-nav__item-content text-center">
                        <i class="mdi mdi-format-list-bulleted mdi-24px"></i>
                        All Activity
                    </div>
                </a>
            </div>

            <div class="mobile-bottom-nav__item">
                <a href="broadcast.php" class="text-white">
                    <div class="mobile-bottom-nav__item-content text-center text-white">
                        <i class="mdi mdi-access-point mdi-24px"></i>
                        Broadcast
                    </div>
                </a>
            </div>
            <div class="mobile-bottom-nav__item">
                <a href="myactivity.php" class="text-white">
                    <div class="mobile-bottom-nav__item-content text-center">
                        <!-- <i class="mdi mdi-view-list mdi-24px"></i>
                        <span class="badge gradient-1 badge-pill badge-primary">3</span> -->

                        <i class="mdi mdi-view-list mdi-24px text-white"> <span
                                    class="badge gradient-2 badge-pill badge-danger"> 3 </span></i>
                        My Activities
                    </div>
                </a>
            </div>
        </nav>
    </div>
</section>